﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMP123_S2019_FinalTestA.Views
{
    public partial class MasterForm : Form
    {
        private static List<string> FirstNameList;
        private static List<string> LastNameList;

        public MasterForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This is the event handler for BackButton clivk event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackButton_Click(object sender, EventArgs e)
        {
            if (MainTabControl.SelectedIndex != 0)
            {
                MainTabControl.SelectedIndex--;
            }
        }

        /// <summary>
        /// This is the event handler for NextButton clivk event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextButton_Click(object sender, EventArgs e)
        {
            if (MainTabControl.SelectedIndex <  MainTabControl.TabPages.Count-1)
            {
                MainTabControl.SelectedIndex++;
            }
        }

        private void FirstNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void MentalAbilitiesLabel_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            displayAbbilities();
        }
        private void displayAbbilities()
        {
            int Random1 = new Random().Next(10, 50);
            FightingDataLabel.Text = Random1.ToString();

            int Random2 = new Random().Next(10, 50);
            AgilityDataLabel.Text = Random2.ToString();

            int Random3 = new Random().Next(10, 50);
            label6.Text = Random3.ToString();

            int Random4 = new Random().Next(10, 50);
            label8.Text = Random4.ToString();

            int Random5 = new Random().Next(10, 50);
            label13.Text = Random5.ToString();

            int Random6 = new Random().Next(10, 50);
            label14.Text = Random6.ToString();

            int Random7 = new Random().Next(10, 50);
            label15.Text = Random7.ToString();

            int R8 = new Random().Next(10, 50);
            label16.Text = Random1.ToString();


        }

        public static void LoadNames()
        {
            FirstNameList = File.ReadAllLines(@"../../Data/firstNames.txt").ToList();
            LastNameList = File.ReadAllLines(@"../../Data/lastNames.txt").ToList();
        }

        public void GenerateNames()
        {
            int RandomNumber1 = new Random().Next(0, FirstNameList.Count);
            FirstNameDataLabel.Text = FirstNameList[RandomNumber1];
            int RandomNumber2 = new Random().Next(0, LastNameList.Count);
            LastNameDataLabel.Text = LastNameList[RandomNumber2];
        }
    }
}
